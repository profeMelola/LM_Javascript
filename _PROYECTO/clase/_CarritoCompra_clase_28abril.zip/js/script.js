// -----------------------------------------------------
// Variables

// Creación de un array de productos (simulando su obtención de una base de datos)
const baseDeDatos = [
    {
        id: 1,
        nombre: 'Patata',
        precio: 1,
        imagen: 'imgs/patata.jpg'
    },
    {
        id: 2,
        nombre: 'Cebolla',
        precio: 1.2,
        imagen: 'imgs/cebolla.jpg'
    },
    {
        id: 3,
        nombre: 'Calabacin',
        precio: 2.1,
        imagen: 'imgs/calabacin.jpg'
    },
    {
        id: 4,
        nombre: 'Fresas',
        precio: 0.6,
        imagen: 'imgs/fresas.jpg'
    }

];

let carrito = [];
const divisa = '€';

//observa el html y pon los selectores adecuados
const DOMitems = document.querySelector('#items'); //mi elemento main
const DOMcarrito = document.querySelector('#carrito');
const DOMtotal = document.querySelector('#total');
const DOMbotonVaciar = document.querySelector('#boton-vaciar');

// -----------------------------------------------------

// Funciones

/**
 * Dibuja todos los productos a partir de la base de datos. 
 * Son los productos a vender.
 * No confundir con el carrito
 */
function renderizarProductos() {
    baseDeDatos.forEach( producto => {
        //Estructura
        const miNodo = document.createElement('div');
        miNodo.classList.add('card','col-sm-4');

        //Body
        const miNodoCardBody = document.createElement('div');
        miNodoCardBody.classList.add('card-body');

        //Img
        const miNodoImagen = document.createElement('img');
        miNodoImagen.classList.add('img-fluid');
        miNodoImagen.setAttribute('src',producto.imagen);

        //Título - H5
        const miNodoTitle = document.createElement('h5');
        miNodoTitle.classList.add('card-title');
        miNodoTitle.textContent = producto.nombre;

        //Precio
        const miNodoPrecio = document.createElement('p');
        miNodoPrecio.classList.add('card-text');
        //miNodoPrecio.textContent = producto.precio+divisa;
        miNodoPrecio.textContent = `${producto.precio}${divisa}`;

        //Boton
        const miNodoBoton = document.createElement('button');
        miNodoBoton.classList.add('btn', 'btn-primary');
        miNodoBoton.setAttribute('marcador',producto.id);
        miNodoBoton.textContent = '+';
        miNodoBoton.addEventListener('click',anyadirProductoAlCarrito);

        //Insertamos
        miNodoCardBody.appendChild(miNodoImagen);
        miNodoCardBody.appendChild(miNodoTitle);
        miNodoCardBody.appendChild(miNodoPrecio);
        miNodoCardBody.appendChild(miNodoBoton);

        miNodo.appendChild(miNodoCardBody);

        DOMitems.appendChild(miNodo);

    });
}

/**
 * Evento para añadir un producto al carrito de la compra
 */
function anyadirProductoAlCarrito(e) {
    carrito.push(e.target.getAttribute('marcador'));
    renderizarCarrito();

}

/**
 * Dibuja todos los productos guardados en el carrito
 */
function renderizarCarrito() {
    // Limpiar carrito
    DOMcarrito.textContent = '';
    DOMcarrito.innerHTML = '';

    // Crear colección sin duplicados. Automático al convertir a Set
    const carritoSinDuplicados = new Set(carrito);

    console.log("****** MI CARRITO ****");
    console.log(carrito);
    console.log("****** MI CARRITO SIN DUPLICADOS ****");
    console.log(carritoSinDuplicados);

    //Recorro los items del carritoSinDuplicados
    carritoSinDuplicados.forEach( marcador => {
        //Obtengo cada producto (miItem) (es un objeto)
        const miItem = getItem(marcador);
        //console.log("miItem:");
        //console.log(miItem);

        //Obtener el ńumero de unidades
        const numeroUnidadesItem =getNumUnidades(marcador);

        /*
        <li class="list-group-item text-right mx-2">
        2 x Calabacin - 2.1€
        <button class="btn btn-danger mx-5"
                            data-item="3" style="margin-left: 1rem;">
                            X
                            </button>
                            </li>*/
        const miNodo = document.createElement('li');
        miNodo.classList.add('list-group-item', 'text-right', 'mx-2');
        miNodo.textContent = `${numeroUnidadesItem} x ${miItem.nombre} - ${miItem.precio}${divisa}`;

        const miBoton = document.createElement('button');
        miBoton.classList.add('btn', 'btn-danger', 'mx-5');
        miBoton.textContent='X';
        miBoton.style.marginLeft = '1rem';
        miBoton.addEventListener('click',borrarItemCarrito);

        miNodo.appendChild(miBoton);
        DOMcarrito.appendChild(miNodo);


    })



    

}

/**
 * Devuelve el item del carrito
 */
function getItem(id){
    let item = null;
    let i = 0;
    let encontrado = false;

    while(!encontrado && i< baseDeDatos.length){
        if (baseDeDatos[i].id == id){
            item = baseDeDatos[i];
            encontrado = true;
        }
        i++;
    }

    return item;
}


/**
 * Devuelve el número de unidades de un mismo producto en el carrito
 */
function getNumUnidades(id){
    let total = 0;
    for (const p of carrito){
        if (p == id) total++;
    }
    return total;
}


/**
 * Evento para borrar un elemento del carrito
 */
function borrarItemCarrito(id,evento) {

}

/**
 * Calcula el precio total teniendo en cuenta los productos repetidos
 */
function calcularTotal() {
   
}

/**
 * Varia el carrito y vuelve a dibujarlo
 */
function vaciarCarrito() {
    //4. formas de borrar un carrito
    carrito = [];
    //carrito.splice(0,carrito.length);
    //carrito.length = 0;
    //while(carrito.length) carrito.pop();

    renderizarCarrito();



}

// -----------------------------------------------------------------------------
// Eventos
// -----------------------------------------------------------------------------
DOMbotonVaciar.addEventListener('click',vaciarCarrito);

// -----------------------------------------------------------------------------
// Inicio
renderizarProductos(); //para cargar los productos en el main con id="items"
renderizarCarrito(); //para cargar los productos en el carrito (ul con id="carrito")
// -----------------------------------------------------------------------------
